/**
 * 监听容器变化
 * @returns
 */
export function useMutationObserver () {
  // const MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver
  // const observer = new MutationObserver(callback)
  // return {}
}
