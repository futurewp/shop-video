export const stage: any = {
  1: '种子期',
  2: '初创期',
  3: '成长期',
  4: '扩张期',
  5: '成熟期',
  6: 'Pre_IPO'
}

export default {
  stage
}
