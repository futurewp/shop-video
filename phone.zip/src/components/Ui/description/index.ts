export { default as UiDescription } from './src/description.vue'
