interface MenuMapperModel {
  children?: string
  idKey?: string
  pIdKey?: string
  label?: string
}

export type {
  MenuMapperModel
}
