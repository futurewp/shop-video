import { Component } from 'vue'

export interface ComponentMode {
  _options: any
  component: Component
}
